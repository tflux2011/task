/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        './**/*.twig',
        './src/js/**/*.js'
    ],
    theme: {
        screens: {
            sm_max: {
                'max': '926px'
            },
            xs: '927px',
            sm: '927px',// Mobile
            md: '1025px',// Tablet
            lg: '1241px',// Laptop
            xl: '1423px',// 1300 + 16 + 16 + 45 + 45 + 1
        },
        container: {
            center: true,
            padding: {
                DEFAULT: '1rem',
                xs: 'calc(1rem + 45px)',
                sm: 'calc(1rem + 45px)',
                md: 'calc(1rem + 45px)',
                lg: 'calc(1rem + 45px)',
            },
        },
        fontFamily: {
            'display': ['Montserrat', 'sans-serif'],
            'body': ['Karla', 'sans-serif'],
        },
        fontSize: {
            xs: '0.75rem',// 12px
            sm: '0.875rem',// 14px
            base: '1rem',// 16px
            lg: '1.125rem',// 18px
            xl: '1.25rem',// 20px
            '2xl': '1.5rem',// 24px
            '3xl': '1.875rem',// 30px
            '4xl': '2.25rem',// 36px
            '5xl': '3rem',// 48px
            '6xl': '3.75rem',// 60px
            '7xl': '4.5rem',// 72px
            '8xl': '6rem',// 96px
            '9xl': '8rem',// 128px
        },
        extend: {
            colors: {
                'blue': '#112A4B',
                'offwhite': '#EAF2F9',
            },
            backgroundImage: {
                'logo-dark': "url('../../src/img/logo-dark.svg')",
                'logo-light': "url('../../src/img/logo-light.svg')",
                'facebook-dark': "url('../../src/img/social-facebook-dark.svg')",
                'facebook-light': "url('../../src/img/social-facebook-light.svg')",
                'twitter-dark': "url('../../src/img/social-twitter-dark.svg')",
                'twitter-light': "url('../../src/img/social-twitter-light.svg')",
                'x-twitter-dark': "url('../../src/img/social-x-twitter-dark.svg')",
                'x-twitter-light': "url('../../src/img/social-x-twitter-light.svg')",
                'instagram-dark': "url('../../src/img/social-instagram-dark.svg')",
                'instagram-light': "url('../../src/img/social-instagram-light.svg')",
                'linkedin-dark': "url('../../src/img/social-linkedin-dark.svg')",
                'linkedin-light': "url('../../src/img/social-linkedin-light.svg')",
                'youtube-dark': "url('../../src/img/social-youtube-dark.svg')",
                'youtube-light': "url('../../src/img/social-youtube-light.svg')",
                'email-dark': "url('../../src/img/email-dark.svg')",
                'email-light': "url('../../src/img/email-light.svg')",
                'phone-dark': "url('../../src/img/phone-dark.svg')",
                'phone-light': "url('../../src/img/phone-light.svg')",
                'location-dark': "url('../../src/img/location-dark.svg')",
                'location-light': "url('../../src/img/location-light.svg')",
                'select-arrow-dark': "url('../../src/img/select-arrow-dark.svg')",
                'select-arrow-light': "url('../../src/img/select-arrow-light.svg')",
                'input-check-dark': "url('../../src/img/input-check-dark.svg')",
                'input-check-light': "url('../../src/img/input-check-light.svg')",
                'xmark-dark': "url('../../src/img/xmark-dark.svg')",
                'xmark-light': "url('../../src/img/xmark-light.svg')",
            },
            borderWidth: {
                '1': '1px',
                '3': '3px'
            },
            spacing: {
                'spacer': 'var(--spacer)',
                'spacerhalf': 'var(--spacerhalf)',
                'spacerdouble': 'var(--spacerdouble)',
                '.5': '2px',
                '1': '4px',
                '1.5': '6px',
                '2': '8px',
                '2.5': '10px',
                '3': '12px',
                '3.5': '14px',
                '4': '16px',
                '8': '32px',
                '16': '64px',
            },
        },
    },
    plugins: [],
}
