<?php
Timber\Timber::init();

require_once('functions/cleanup.php');
require_once('functions/enqueue.php');
require_once('functions/options.php');
require_once('functions/views.php');
require_once('functions/acf.php');
require_once('functions/timber.php');
