<?php
/* Template Name: Home */
$context = Timber::context();
$post = Timber::get_post();
$context['post'] = $post;
Timber::render('pages/page.twig', $context);
?>
