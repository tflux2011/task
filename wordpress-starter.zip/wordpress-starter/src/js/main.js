import '../css/main.scss'
import 'swiper/css'
// import 'swiper/css/navigation'
// import 'swiper/css/pagination'
import Swiper from 'swiper'
import { Navigation, Pagination } from 'swiper/modules'

function mobileNav() {
    // CODE GOES HERE
}

function heroSlider() {
    // Slider powered by Swiper
    // https://swiperjs.com/get-started

    const slider = document.querySelector('.block-hero-slider .swiper')

    if (!slider) return

    // CODE GOES HERE
}

let readystate = setInterval(() => {
    if (document.readyState === 'complete') {
        clearInterval(readystate)

        mobileNav()
        heroSlider()
    }
}, 100)
