import '../css/main.scss'
import 'swiper/css'
// import 'swiper/css/navigation'
// import 'swiper/css/pagination'
import Swiper from 'swiper'
import { Navigation, Pagination } from 'swiper/modules'

function mobileNav() {
    const hamburger = document.querySelector('.header-mobile .hamburger');
    const mobileMenu = document.querySelector('.header-mobile .menu');
    
    if (!hamburger || !mobileMenu) return;
    
    hamburger.addEventListener('click', function() {
        mobileMenu.classList.toggle('active');
        
        // Animate hamburger to X
        const bars = hamburger.querySelectorAll('div');
        hamburger.classList.toggle('active');
        
        if (hamburger.classList.contains('active')) {
            // Transform to X
            bars[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
            bars[1].style.opacity = '0';
            bars[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
        } else {
            // Reset to hamburger
            bars[0].style.transform = 'none';
            bars[1].style.opacity = '1';
            bars[2].style.transform = 'none';
        }
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.header-mobile') && 
            mobileMenu.classList.contains('active')) {
            mobileMenu.classList.remove('active');
            hamburger.classList.remove('active');
            
            // Reset hamburger
            const bars = hamburger.querySelectorAll('div');
            bars[0].style.transform = 'none';
            bars[1].style.opacity = '1';
            bars[2].style.transform = 'none';
        }
    });
    
    // Mobile dropdown functionality
    const dropdownLinks = mobileMenu.querySelectorAll('.has-dropdown > a');
    
    dropdownLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            // Prevent default only for items with dropdowns
            if (link.parentNode.classList.contains('has-dropdown')) {
                e.preventDefault();
            }
            
            // Toggle 'open' class on parent li
            const parentLi = link.parentNode;
            parentLi.classList.toggle('open');
            
            // Close other open dropdowns
            dropdownLinks.forEach(function(otherLink) {
                if (otherLink !== link && otherLink.parentNode.classList.contains('open')) {
                    otherLink.parentNode.classList.remove('open');
                }
            });
        });
    });
}

function heroSlider() {
    // Slider powered by Swiper
    // https://swiperjs.com/get-started

    const slider = document.querySelector('.block-hero-slider .swiper')

    if (!slider) return

    // Initialize Swiper with modules
    const swiper = new Swiper(slider, {
        modules: [Navigation, Pagination],
        // Enable loop mode
        loop: true,
        
        // Add smooth fade effect
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
        
        // Configure speed
        speed: 1000,
        
        // Add autoplay
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
        
        // Add pagination
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        
        // Uncomment to add navigation
        // navigation: {
        //     nextEl: '.swiper-button-next',
        //     prevEl: '.swiper-button-prev',
        // },
    });
    
    // Pause autoplay on hover (optional)
    const sliderContainer = document.querySelector('.block-hero-slider');
    if (sliderContainer && swiper.autoplay && swiper.autoplay.running) {
        sliderContainer.addEventListener('mouseenter', function() {
            swiper.autoplay.stop();
        });
        
        sliderContainer.addEventListener('mouseleave', function() {
            swiper.autoplay.start();
        });
    }
    
    // Add accessibility attributes
    const slides = document.querySelectorAll('.block-hero-slider .swiper-slide');
    slides.forEach(function(slide, index) {
        slide.setAttribute('aria-label', 'Slide ' + (index + 1));
        slide.setAttribute('role', 'group');
    });
}

let readystate = setInterval(() => {
    if (document.readyState === 'complete') {
        clearInterval(readystate)

        mobileNav()
        heroSlider()
    }
}, 100)