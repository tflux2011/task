<?php

// ACF title updater
function post_title_updater($post_id) {
    $my_post = [];
    $my_post['ID'] = $post_id;
    if (get_post_type() == 'team') {
        $my_post['post_title'] = get_field('name');
        $my_post['post_name'] = sanitize_title(get_field('name'));
    }
    wp_update_post($my_post);
}
add_action('acf/save_post', 'post_title_updater', 20);

// ACF enable admin options page
if (function_exists('acf_add_options_page')) {
    acf_add_options_page();
}
