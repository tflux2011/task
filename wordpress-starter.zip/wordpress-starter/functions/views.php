<?php

function custom_views($original_template) {
    if ($_SERVER['REQUEST_URI'] == '/') {
        return TEMPLATEPATH . '/index.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/impact/') {
        //     return TEMPLATEPATH . '/page-impact.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/impact/media/') {
        //     return TEMPLATEPATH . '/page-impact.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/impact/food-wine-partnership/') {
        //     return TEMPLATEPATH . '/page-impact.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/impact/testimonials/') {
        //     return TEMPLATEPATH . '/page-impact.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/about/') {
        //     return TEMPLATEPATH . '/page-about.php';
    } elseif ($_SERVER['REQUEST_URI'] == '/news/') {
        return TEMPLATEPATH . '/page-news.php';
        // } elseif ($_SERVER['REQUEST_URI'] == '/about/') {
        //     return TEMPLATEPATH . '/page-about.php';
    } else {
        return $original_template;
    }
}
add_filter('template_include', 'custom_views');
