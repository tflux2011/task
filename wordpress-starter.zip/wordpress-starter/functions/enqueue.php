<?php

// Defer scripts
if (!is_admin()) {
    add_filter(
        'script_loader_tag',
        function ($tag, $handle) {
            return str_replace(' src', ' defer src', $tag);
        },
        10,
        2
    );
}

// Enqueue assets
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('theme-css', get_template_directory_uri() . '/dist/css/main.min.css', false, @md5_file(get_template_directory() . '/dist/css/main.min.css'));
    // wp_enqueue_script('jquery');
    // wp_deregister_script('jquery');
    wp_enqueue_script('theme-js', get_template_directory_uri() . '/dist/js/main.min.js', false, @md5_file(get_template_directory() . '/dist/js/main.min.js'));
});
