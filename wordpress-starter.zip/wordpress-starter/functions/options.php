<?php

// Hide admin bar
show_admin_bar(false);

// Enable media infinite scrolling
add_filter('media_library_infinite_scrolling', '__return_true');

// Enable post thumbnails
add_theme_support('post-thumbnails');

// Remove default thumbnail sizes
add_filter('intermediate_image_sizes', function ($sizes) {
    return array_diff($sizes, ['medium_large', 'large', '1536x1536']);
});

function my_remove_menu_pages() {
    remove_menu_page('edit.php');
    remove_menu_page('edit-comments.php');
}
add_action('admin_menu', 'my_remove_menu_pages', 999);

function remove_wp_nodes() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu('new-post');
    $wp_admin_bar->remove_menu('comments');
}
add_action('admin_bar_menu', 'remove_wp_nodes', 999);

// Disable gutenberg editor
add_filter('use_block_editor_for_post', '__return_false');

// Disable autosave
function disable_autosave() {
    wp_deregister_script('autosave');
}
add_action('admin_init', 'disable_autosave');

// Disable revisions
function remove_posttype_supports() {
    remove_post_type_support('page', 'revisions');
    remove_post_type_support('post', 'revisions');
}
add_action('init', 'remove_posttype_supports');

// Disable editor media button
add_filter('wp_editor_settings', function ($settings) {
    $settings['media_buttons'] = false;
    return $settings;
});

// Add menus
function register_my_menus() {
    register_nav_menus([
        'main-menu' => __('Main Menu'),
    ]);
}
add_action('init', 'register_my_menus');

// Customize editor tags
function customize_editor_tags($settings) {
    $settings['block_formats'] = 'Paragraph=p;Heading 1=h1;Heading 2=h2;Heading 3=h3;';
    return $settings;
}
add_filter('tiny_mce_before_init', 'customize_editor_tags');

// Redirect after logging in
// function login_redirect($redirect_to, $request, $user) {
//     return home_url('/wp-admin/admin.php?page=vxcf_leads');
// }
// add_filter('login_redirect', 'login_redirect', 10, 3);

// Add custom css to admin
// function admin_custom_css() {
//     echo '<style></style>';
// }
// add_action('admin_head', 'admin_custom_css');

// Add editor styles
// function cd_add_editor_styles() {
//     add_editor_style('css/tinymce.css');
// }
// add_action('init','cd_add_editor_styles');
