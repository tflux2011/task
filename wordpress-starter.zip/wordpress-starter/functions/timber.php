<?php

function getPageHashLinks($id) {
    $object = [];

    if (have_rows('content', $id)) {
        while (have_rows('content', $id)) :
            the_row();
            $hash = get_sub_field('hash');

            if (isset($hash['link'][0])) {
                $object[] = [
                    'text' => $hash['text'],
                    'slug' => sanitize_title($hash['text']),
                ];
            }
        endwhile;
    }

    return $object;
}

// Timber change directory name
Timber::$dirname = ['templates', 'views'];

// Filter bold text
add_filter('timber/twig', function ($twig) {
    $twig->addExtension(new Twig\Extension\StringLoaderExtension());
    $twig->addFilter(
        new Twig\TwigFilter(
            'bold_text',
            function ($string) {
                $regexExp = '/(.*)\*(.*)\*(.*)/';
                $string = preg_replace($regexExp, '$1<b>$2</b>$3', $string);
                return $string;
            }
        )
    );
    return $twig;
});

// Timber add to context
function add_to_context($context) {
    $context['menu'] = Timber::get_menu('main-menu');
    $context['current_url'] = $_SERVER['REQUEST_URI'];
    $context['options'] = get_fields('options');
    $context['properties'] = Timber::get_posts([
        'posts_per_page' => -1,
        'post_type' => 'properties',
        'order' => 'ASC',
        'orderby' => 'date',
    ]);
    return $context;
}
add_filter('timber/context', 'add_to_context');
